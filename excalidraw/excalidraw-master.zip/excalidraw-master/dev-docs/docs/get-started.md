---
sidebar_position: 1
title: Introduction
---

Want to integrate Excalidraw into your app? Head over to the [package docs](/docs/package/overview).

If you're looking into the Excalidraw codebase itself, start [here](/docs/codebase/overview).
